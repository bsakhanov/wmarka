<?php
/**
 * @package       Blank page
 * @version       2.0.1
 * @Author        Sergey Tolkachyov
 * @copyright     Copyright (c) 2018 - 2025 Sergey Tolkachyov. All rights reserved.
 * @license       GNU/GPL3 http://www.gnu.org/licenses/gpl-3.0.html
 * @link          https://web-tolk.ru/dev/components/blank-page-component-for-joomla
 * @since         1.0.0
 */

namespace Joomla\Component\Blank\Administrator\Extension;

use Joomla\CMS\Component\Router\RouterServiceInterface;
use Joomla\CMS\Component\Router\RouterServiceTrait;
use Joomla\CMS\Extension\BootableExtensionInterface;
use Joomla\CMS\Extension\MVCComponent;
use Psr\Container\ContainerInterface;
use function defined;

defined('_JEXEC') or die;

class BlankComponent extends MVCComponent implements
	BootableExtensionInterface, RouterServiceInterface
{
	use RouterServiceTrait;

	/**
	 * Booting the extension. This is the function to set up the environment of the extension like
	 * registering new class loaders, etc.
	 *
	 *
	 * @param   ContainerInterface  $container  The container
	 *
	 * @since 1.0.0
	 */
	public function boot(ContainerInterface $container)
	{

	}
}

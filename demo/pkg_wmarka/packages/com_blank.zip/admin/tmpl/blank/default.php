<?php
/**
 * @package       Blank page
 * @version       2.0.1
 * @Author        Sergey Tolkachyov
 * @copyright     Copyright (c) 2018 - 2025 Sergey Tolkachyov. All rights reserved.
 * @license       GNU/GPL3 http://www.gnu.org/licenses/gpl-3.0.html
 * @link       https://web-tolk.ru/dev/components/blank-page-component-for-joomla
 * @since         1.0.0
 */

use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;
?>

<div class="main-card p-4 shadow mb-4 fs-3">
	<?php echo Text::_('COM_BLANK_DESC'); ?>
</div>

<div class="main-card">
    <div class="row row-cols-1 row-cols-md-2">
        <div class="col card">
            <div class="card-body">
				<?php echo Text::_('COM_BLANK_DESC_FULL'); ?>
            </div>
        </div>
        <div class="col card bg-light">
            <div class="card-body">
                <h3 class="card-title"><?php echo Text::_('COM_BLANK_AUTHORS'); ?></h3>
				<?php echo Text::_('COM_BLANK_AUTHORS_DESC'); ?>
            </div>
        </div>

    </div>

</div>

